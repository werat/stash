# Jabbaq

![Jabba with coffee](/docs/jabba.gif "http://bleachydoesdoodles.tumblr.com/post/41271258312/jabba-enjoys-his-coffee")

Jabbaq is a distributed fault-tolerant task queue.

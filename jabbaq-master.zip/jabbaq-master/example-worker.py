#!/usr/bin/env python3

import time
import logging
import random

from jabbaq.backend.mongo import MongoDbBackend
from jabbaq.worker import Worker, JobContext  # noqa


class Work(object):
    def __init__(self, backend):
        self.backend = backend

    def __call__(self, ctx: JobContext):
        logging.info('[%s] Processing job with type %s', ctx.worker.id, ctx.job.type)
        # check if job was cancelled or revoked
        ctx.interrupt_if_requested()

        if ctx.job.type == 'typeA':
            for _ in range(4):
                time.sleep(1 + random.random())

            self.backend.create_resource(tags=['stdout'])
            self.backend.create_resource(tags=['stderr'])

            self.backend.create_resource(tags=['DATA'])

        if ctx.job.type == 'typeB':
            resource = self.backend.get_resource_by_id(ctx.job.resource_id)

            if 'stdout' in resource.tags:
                raise Exception('lol')

            if 'stderr' in resource.tags:
                # ctx.worker.request_stop()
                pass


def setup_backend(db_uri):
    import pymongo
    client = pymongo.MongoClient(db_uri)
    client.drop_database(client.get_default_database().name)


if __name__ == '__main__':
    logging.basicConfig(format='%(asctime)s\t%(levelname)s:\t%(message)s', level=logging.INFO)

    db_uri = 'mongodb://localhost/jabbaq'

    setup_backend(db_uri)

    backend = MongoDbBackend(db_uri)

    backend.create_observer(resource_tag='html', job_type='typeA')
    backend.create_observer(resource_tag='stdout', job_type='typeB')
    backend.create_observer(resource_tag='stderr', job_type='typeB')

    for _ in range(4):
        backend.create_resource(tags=['html'], props={'payload': 'OZON HTML DATA'})

    worker_A = Worker('worker-A', ['typeA'], Work(backend), backend)
    worker_B = Worker('worker-B', ['typeB'], Work(backend), backend)

    worker_A.start()
    worker_B.start()

    try:
        while worker_A.is_running or worker_B.is_running:
            time.sleep(1)

    except KeyboardInterrupt:

        print('stopping workers')
        worker_A.request_stop()
        worker_B.request_stop()

        print('wait for workers')
        worker_A.join()
        worker_B.join()

    for resource in backend.get_resources_by_tag('DATA'):
        print(resource)
        backend.delete_resource_by_id(resource.id)

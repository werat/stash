from copy import deepcopy
from functools import wraps
from threading import RLock
from time import time as ts_now
from uuid import uuid4

from ..api import (
    Backend,
    Resource, ResourceStatus, Job, JobStatus, Observer,
    ConcurrencyError
)


class InMemoryBackend(Backend):
    def __init__(self):
        self._resources = {}
        self._observers = {}
        self._jobs = {}
        self._rlock = RLock()

        self._types = {Resource: self._resources,
                       Observer: self._observers,
                       Job: self._jobs}

    def synchronized(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            with self._rlock:
                return func(self, *args, **kwargs)
        return wrapper

    @synchronized
    def _create(self, klass, props):
        obj = klass(uuid4().hex, props)
        return deepcopy(self._types[klass].setdefault(obj.id, obj))

    @synchronized
    def _get_by_id(self, klass, id_):
        return self._types[klass][id_]

    @synchronized
    def _get_by_predicate(self, klass, predicate):
        return deepcopy([obj for obj in self._types[klass].values()
                         if predicate(obj)])

    @synchronized
    def _get_by_props(self, klass, props):
        def match(left, right):
            for k, v in right.items():
                if k not in left:
                    return False
                if v != left[k]:
                    return False
            return True

        return self._get_by_predicate(klass, lambda x: match(x.props, props))

    @synchronized
    def _update(self, obj, version, props):
        if obj.version != version:
            raise ConcurrencyError('version mismatch')

        obj.version += 1
        obj.ts = ts_now()

        props.pop('version', None)  # remove version just in case
        obj.props.update(props.copy())

        return deepcopy(obj)

####################################################################

    @synchronized
    def create_resource(self, tags, props={}):
        props = props.copy()
        props['tags'] = tags if isinstance(tags, list) else [tags]
        # create draft resource
        resource = self._create(Resource, props)
        # find all observers for these tags
        observers = self._get_by_predicate(Observer, lambda o: o.resource_tag in resource.tags)
        # create jobs for every observer
        jobs = [self.create_job(obs.job_type, {'resource_id': resource.id,
                                               'observer_id': obs.id,
                                               'status': ResourceStatus.DRAFT})
                for obs in observers]
        # commit resource
        resource = self.update_resource(resource.id, resource.version,
                                        {'status': ResourceStatus.READY,
                                         'jobs': [job.id for job in jobs]})
        # commit jobs
        for job in jobs:
            self.update_job(job.id, job.version, {'status': JobStatus.READY})
        # we're done
        return resource

    def get_resource_by_id(self, id_):
        return self._get_by_id(Resource, id_)

    def get_resources_by_props(self, props):
        return self._get_by_props(Resource, props)

    def update_resource(self, id_, version, props):
        return self._update(self._resources[id_], version, props)

    def delete_resource_by_id(self, id_):
        raise NotImplementedError

    def create_observer(self, resource_tag, job_type, props={}):
        props = props.copy()
        props['resource_tag'] = resource_tag
        props['job_type'] = job_type
        return self._create(Observer, props)

    def get_observer_by_id(self, id_):
        return self._get_by_id(Observer, id_)

    def get_observers_by_props(self, props):
        return self._get_by_props(Observer, props)

    def update_observer(self, id_, version, props):
        return self._update(self._observers[id_], version, props)

    def delete_observer_by_id(self, id_):
        raise NotImplementedError

    @synchronized
    def try_acquire_job(self, types, worker_id):
        for job in self._jobs.values():
            if job.status == JobStatus.READY and job.type in types:
                try:
                    # try lock this job
                    obj = self.update_job(job.id, job.version,
                                          {'status': JobStatus.RUNNING,
                                           'worker_id': worker_id,
                                           'worker_heartbeat': ts_now()})
                except ConcurrencyError:
                    pass
                else:
                    return deepcopy(obj)

        # no available jobs
        return None

    def create_job(self, type_, props):
        props = props.copy()
        props.setdefault('status', JobStatus.READY)  # default state is READY
        props['type'] = type_
        return self._create(Job, props)

    def get_job_by_id(self, id_):
        return self._get_by_id(Job, id_)

    def get_jobs_by_props(self, props):
        return self._get_by_props(Job, props)

    def update_job(self, id_, version, props):
        return self._update(self._jobs[id_], version, props)

    def delete_job_by_id(self, id_):
        raise NotImplementedError

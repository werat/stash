from time import time as ts_now
from uuid import uuid4

import pymongo

from ..api import (
    Backend,
    Resource, ResourceStatus, Job, JobStatus, Observer,
    ConcurrencyError, RetriableError
)


def _object_from_doc(klass, doc):
    return klass(doc.pop('id'), doc)


def _props_to_query(props):
    # TODO: do something with nested documents
    return props


class MongoDbBackend(Backend):
    def __init__(self, db_uri):
        """MongoDB backend implementation

        Args:
            db_uri (str): a full `mongodb URI <http://dochub.mongodb.org/core/connections>`_
        """
        self._validate_db_uri(db_uri)
        self._client = pymongo.MongoClient(db_uri)
        self._db = self._client.get_default_database()

        self._resources = self._db['resources']
        self._observers = self._db['observers']
        self._jobs = self._db['jobs']
        self._ensure_indexes()

        self._types = {Resource: self._resources,
                       Observer: self._observers,
                       Job: self._jobs}

    def _validate_db_uri(self, uri):
        res = pymongo.uri_parser.parse_uri(uri)
        if 'database' not in res:
            raise Exception('You should explicitly specify database')

    def _ensure_indexes(self):
        def idx(*args, **kwargs):
            keys = [(field, pymongo.ASCENDING) for field in args]
            return pymongo.IndexModel(keys, **kwargs)

        self._resources.create_indexes([idx('id', unique=True),
                                        idx('id', 'version'),
                                        idx('tags')])

        self._observers.create_indexes([idx('id', unique=True),
                                        idx('id', 'version'),
                                        idx('resource_tag')])

        self._jobs.create_indexes([idx('id', unique=True),
                                   idx('id', 'version'),
                                   idx('type', 'status')])

    def _get_collection(self, klass):
        return self._types[klass]

    def _create(self, klass, *args):
        obj = klass(uuid4().hex, *args)
        doc = obj.to_dict()

        try:
            self._get_collection(klass).insert_one(doc)
        except pymongo.errors.AutoReconnect:
            raise RetriableError('insert_one has failed due to the AutoReconnect error')

        return obj

    def _get_by_id(self, klass, id_):
        try:
            doc = self._get_collection(klass).find_one({'id': id_}, projection={'_id': False})
        except pymongo.errors.AutoReconnect:
            raise RetriableError('find_one has failed due to the AutoReconnect error')

        return _object_from_doc(klass, doc)

    def _get_by_query(self, klass, query):
        try:
            c = self._get_collection(klass)
            r = c.find(query, projection={'_id': False},
                       cursor_type=pymongo.cursor.CursorType.EXHAUST)
        except pymongo.errors.AutoReconnect:
            raise RetriableError('find has failed due to the AutoReconnect error')

        return [_object_from_doc(klass, doc) for doc in r]

    def _get_by_props(self, klass, props):
        return self._get_by_query(klass, _props_to_query(props))

    def _update(self, klass, id_, version, props):
        # TODO: probably validate document somewhere here
        query = {'id': id_, 'version': version}

        props = props.copy()
        props.pop('version', None)  # remove version just in case
        props['ts'] = ts_now()

        update = {'$inc': {'version': 1},
                  '$set': _props_to_query(props)}
        try:
            c = self._get_collection(klass)
            r = c.find_one_and_update(query, update, projection={'_id': False},
                                      return_document=pymongo.collection.ReturnDocument.AFTER)
        except pymongo.errors.AutoReconnect:
            raise RetriableError('find_one_and_update has failed due to AutoReconnect')

        if r is None:
            obj = self._get_by_id(klass, id_)
            raise ConcurrencyError('invalid version: {} vs {}'.format(version, obj.version))

        return _object_from_doc(klass, r)

    def _delete_by_id(self, klass, id_):
        try:
            r = self._get_collection(klass).delete_one({'id': id_})
        except pymongo.errors.AutoReconnect:
            raise RetriableError('delete_one has failed due to AutoReconnect')

        if r.deleted_count == 0:
            return None

        assert r.deleted_count == 1
        return id_  # TODO: return something more meaningful

    ####################################################################
    #                   PUBLIC INTERFACE STARTS HERE                   #
    ####################################################################

    def create_resource(self, tags, props={}):
        props = props.copy()
        props['tags'] = tags if isinstance(tags, list) else [tags]
        # create draft resource
        resource = self._create(Resource, props)
        # find all observers for these tags
        observers = self._get_by_query(Observer, {'resource_tag': {'$in': resource.tags}})
        # create jobs for every observer
        jobs = [self.create_job(obs.job_type, {'resource_id': resource.id,
                                               'observer_id': obs.id,
                                               'status': ResourceStatus.DRAFT})
                for obs in observers]
        # commit resource
        resource = self.update_resource(resource.id, resource.version,
                                        {'status': ResourceStatus.READY,
                                         'jobs': [job.id for job in jobs]})
        # commit jobs
        for job in jobs:
            self.update_job(job.id, job.version, {'status': JobStatus.READY})
        # we're done
        return resource

    def get_resource_by_id(self, id_):
        return self._get_by_id(Resource, id_)

    def get_resources_by_props(self, props):
        return self._get_by_props(Resource, props)

    def update_resource(self, id_, version, props):
        return self._update(Resource, id_, version, props)

    def delete_resource_by_id(self, id_):
        return self._delete_by_id(Resource, id_)

    def create_observer(self, resource_tag, job_type, props={}):
        props = props.copy()
        props['resource_tag'] = resource_tag
        props['job_type'] = job_type
        return self._create(Observer, props)

    def get_observer_by_id(self, id_):
        return self._get_by_id(Observer, id_)

    def get_observers_by_props(self, props):
        return self._get_by_props(Observer, props)

    def update_observer(self, id_, version, props):
        return self._update(Observer, id_, version, props)

    def delete_observer_by_id(self, id_):
        return self._delete_by_id(Observer, id_)

    def try_acquire_job(self, types, worker_id):
        query = {'type': {'$in': types}, 'status': JobStatus.READY}
        update = {'$inc': {'version': 1},
                  '$set': {'status': JobStatus.RUNNING,
                           'worker_id': worker_id,
                           'worker_heartbeat': ts_now()}}
        try:
            c = self._get_collection(Job)
            r = c.find_one_and_update(query, update, projection={'_id': False},
                                      return_document=pymongo.collection.ReturnDocument.AFTER)
        except pymongo.errors.AutoReconnect:
            raise RetriableError('find_one_and_update has failed due to the AutoReconnect error')

        if r:
            return _object_from_doc(Job, r)

        # there are no available jobs
        return None

    def create_job(self, type_, props={}):
        props = props.copy()
        props.setdefault('status', JobStatus.READY)  # default state is READY
        props['type'] = type_
        return self._create(Job, props)

    def get_job_by_id(self, id_):
        return self._get_by_id(Job, id_)

    def get_jobs_by_props(self, props):
        return self._get_by_props(Job, props)

    def update_job(self, id_, version, props):
        return self._update(Job, id_, version, props)

    def delete_job_by_id(self, id_):
        return self._delete_by_id(Job, id_)

    ####################################################################
    #                   PUBLIC EXTENSION METHODS                       #
    ####################################################################

    def get_resources_by_tag(self, tag):
        return self.get_resources_by_props({'tags': tag})

    def get_observers_by_resource_tag(self, resource_tag):
        return self.get_observers_by_props({'resource_tag': resource_tag})

    def get_observers_by_job_type(self, job_type):
        return self.get_observers_by_props({'job_type': job_type})

    def get_jobs_by_type(self, type_):
        return self.get_jobs_by_props({'type': type_})

    def get_jobs_by_resource_id(self, resource_id):
        return self.get_jobs_by_props({'resource_id': resource_id})

    def get_jobs_by_observer_id(self, observer_id):
        return self.get_jobs_by_props({'observer_id': observer_id})

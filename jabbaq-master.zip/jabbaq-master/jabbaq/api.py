from time import time as ts_now

from magic_repr import make_repr


class ConcurrencyError(Exception):
    pass


class RetriableError(Exception):
    pass


class _Enum(object):
    @classmethod
    def items(cls):
        return {k.lower() for k in cls.__dict__.keys() if not k.startswith('__')}


class ResourceStatus(_Enum):
    DRAFT = 'draft'
    READY = 'ready'


class JobStatus(_Enum):
    DRAFT = 'draft'
    READY = 'ready'
    RUNNING = 'running'
    COMPLETED = 'completed'
    CANCELLED = 'cancelled'


class _Object(object):
    __repr__ = make_repr()

    def __init__(self, id_, props):
        super(_Object, self).__setattr__('id', id_)
        super(_Object, self).__setattr__('props', props.copy())
        self.defaults()
        self.validate()

    def defaults(self):
        pass

    def validate(self):
        pass

    def to_dict(self):
        # # for python3
        # return {'id': self.id, **self.props}
        d = self.props.copy()
        d['id'] = self.id
        return d

    def __getattr__(self, name):
        if name.startswith('__'):
            return super(_Object, self).__getattr__(name)
        return self.props[name]

    def __setattr__(self, name, value):
        if name.startswith('__'):
            return super(_Object, self).__setattr__(name)
        self.props[name] = value


class Resource(_Object):
    def defaults(self):
        self.props.setdefault('version', 0)
        self.props.setdefault('ts', ts_now())
        self.props.setdefault('tags', [])
        self.props.setdefault('status', ResourceStatus.DRAFT)
        self.props.setdefault('jobs', [])

    def validate(self):
        assert self.status in ResourceStatus.items()


class Observer(_Object):
    def defaults(self):
        self.props.setdefault('version', 0)
        self.props.setdefault('ts', ts_now())
        self.props.setdefault('resource_tag', None)
        self.props.setdefault('job_type', None)

    def validate(self):
        assert self.resource_tag
        assert self.job_type


class Job(_Object):
    def defaults(self):
        self.props.setdefault('version', 0)
        self.props.setdefault('ts', ts_now())
        self.props.setdefault('type', None)
        self.props.setdefault('status', JobStatus.DRAFT)
        self.props.setdefault('worker_id', None)
        self.props.setdefault('worker_heartbeat', None)

    def validate(self):
        assert self.type
        assert self.status in JobStatus.items()


class Backend(object):
    def create_resource(self, tags, props):
        pass

    def update_resource(self, id_, version, props):
        pass

    def get_resource_by_id(self, id_):
        pass

    def delete_resource_by_id(self, id_):
        pass

    def create_observer(self, resource_tag, job_type, props):
        pass

    def update_observer(self, id_, version, props):
        pass

    def get_observer_by_id(self, id_):
        pass

    def get_observers_by_props(self, props):
        pass

    def delete_observer_by_id(self, id_):
        pass

    def try_acquire_job(self, types, worker_id):
        """
            Should be used by worker
        """
        pass

    def create_job(self, type_, props):
        pass

    def update_job(self, id_, version, props):
        pass

    def get_job_by_id(self, id_):
        pass

    def get_jobs_by_props(self, props):
        pass

    def delete_job_by_id(self, id_):
        pass

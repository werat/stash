import logging
import math
import random
import signal
import sys
import threading
import time

from ..api import ResourceStatus, JobStatus


ONE_HOUR = 3600
TEN_MINUTES = 600
TWO_MINUTES = 120


class Watchdoge(object):
    """
        1. Collects garbage (unused draft resources and jobs)
        2. Fixes forgotten draft jobs if possible
    """

    def __init__(self, backend):
        self._backend = backend

        self._stop = threading.Event()
        self._main_loop_thread = threading.Thread(target=self._loop)

        self._logger = logging.getLogger(__name__)

    def setup_shutdown_handlers(self):
        def shutdown_handler(signum, frame):
            print('request watchdoge to stop')
            self.request_stop()

        signal.signal(signal.SIGINT, shutdown_handler)
        signal.signal(signal.SIGTERM, shutdown_handler)

    @property
    def is_running(self):
        return self._main_loop_thread.is_alive()

    def start(self):
        self._main_loop_thread.start()

    def request_stop(self):
        self._stop.set()

    def join(self):
        self._main_loop_thread.join()

    def stop(self):
        self.request_stop()
        self.join()

    def _collect_garbage_resources_and_jobs(self):
        for resource in self._backend.get_resources_by_props({'status': ResourceStatus.DRAFT}):
            if time.time() - resource.ts < TEN_MINUTES:
                continue  # wait for ten minutes just in case

            # now this resource is really a piece of garbage
            # delete it and all his jobs

            self._logger.info('[GC]: cleanup resource %s', resource.id)

            for job_id in resource.jobs:
                self._backend.delete_job_by_id(job_id)
                self._logger.info('[GC]: removed job %s', job_id)

            self._backend.delete_resource_by_id(resource.id)
            self._logger.info('[GC]: removed resource %s', resource.id)

    def _try_fix_forgotten_jobs(self):
        for job in self._backend.get_jobs_by_props({'status': JobStatus.DRAFT}):
            if time.time() - job.ts < TWO_MINUTES:
                continue  # wait for two minutes just in case

            # so this job has been in the DRAFT state for about two minutes now
            # if parent resource is in the READY state,
            # then promote job to the READY state

            resource = self._backend.get_resource_by_id(job.resource_id)

            if resource.status == ResourceStatus.READY:
                self._backend.update_job(job.id, job.version,
                                         {'status': JobStatus.READY})
                self._logger.info('[DOGE]: promoted job %s', job.id)

    def _invalidate_lost_jobs(self):
        for job in self._backend.get_jobs_by_props({'status': JobStatus.RUNNING}):
            if time.time() - job.worker_heartbeat < ONE_HOUR:
                continue  # one hour timeout

            self._backend.update_job(job.id, job.version,
                                     {'status': JobStatus.READY,
                                      'worker_id': None,
                                      'worker_heartbeat': None})
            self._logger.info('[DOGE]: invalidated job %s', job.id)

    def _loop(self):
        while True:
            if self._stop.is_set():
                break

            self._collect_garbage_resources_and_jobs()
            self._try_fix_forgotten_jobs()
            self._invalidate_lost_jobs()

            time.sleep(math.e + random.random())


def entrypoint():
    """
        Use it only for debug/develompent
    """
    logging.basicConfig(format='%(asctime)s\t%(levelname)s:\t%(message)s', level=logging.INFO)

    import argparse
    from ..backend import MongoDbBackend

    parser = argparse.ArgumentParser()
    parser.add_argument('--db-conn', help='MongoDB connection',
                        default='mongodb://localhost/jabbaq')
    args = parser.parse_args()

    watchdoge = Watchdoge(MongoDbBackend(args.db_conn))
    watchdoge.setup_shutdown_handlers()
    watchdoge.start()
    watchdoge.join()

    if not watchdoge._stop.is_set():
        # most likely an exception in _main_loop_thread
        sys.exit(1)

from setuptools import setup, find_packages

setup(
    name='jabbaq',
    version='0.0.1',
    description='Distributed task queue',
    url='https://github.com/werat/jabbaq',
    author='Andy Yankovsky',
    author_email='weratt@gmail.com',
    license='MIT',
    packages=find_packages(exclude=['docs', 'tests']),
    install_requires=['pymongo', 'repr'],
    extras_require={
        'test': ['pytest', 'coverage'],
    },
    entry_points={
        'console_scripts': [
            'jabbaq-watchdoge=jabbaq.services.watchdoge:entrypoint',
        ],
    },
)

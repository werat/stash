import abc
import threading

import pymongo


class BackendError(Exception):
    pass


class BackendCASError(BackendError):
    pass


class BackendNetworkError(BackendError):
    pass


class Backend(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def list(self):
        pass

    @abc.abstractmethod
    def get(self, task_id):
        pass

    @abc.abstractmethod
    def create(self, task):
        pass

    @abc.abstractmethod
    def save(self, task):
        pass

    @abc.abstractmethod
    def delete(self, task_id):
        pass

    @classmethod
    def create_instance(cls, name, config):
        for backend in cls.__subclasses__():
            if backend.__name__ == name:
                return backend(config)
        raise Exception('Unknown backend {0}'.format(name))


class InMemoryBackend(Backend):
    def __init__(self, config):
        self.tasks = {}
        self._lock = threading.Lock()

    def list(self):
        with self._lock:
            return self.tasks.values()

    def get(self, task_id):
        with self._lock:
            return self.tasks.get(task_id, None)

    def create(self, task):
        with self._lock:
            if task['id'] in self.tasks:
                raise BackendError('Task with id {} already exists'.format(task['id']))

            self.tasks[task['id']] = task

        return task.copy()

    def save(self, task):
        with self._lock:
            if self.tasks[task['id']]['term'] != task['term']:
                raise BackendCASError('Abort CAS, terms are different')

            task['term'] += 1
            self.tasks[task['id']] = task

        return task.copy()

    def delete(self, task_id):
        with self._lock:
            return self.tasks.pop(task_id, None)


class MongoDbBackend(Backend):
    db_name = 'jabba'
    collection_name = 'tasks'

    def __init__(self, config):
        self.client = pymongo.MongoClient()
        self.db = self.client[self.db_name]
        self.collection = self.db[self.collection_name]

    def list(self):
        try:
            for document in self.collection.find(projection={'_id': False}):
                yield document
        except pymongo.errors.AutoReconnect:
            # make sure client is aware that list can produce an incomplete set
            # TODO: figure out a wayt to tell the client that set is incomplete
            raise BackendNetworkError('find has failed, retry')

    def get(self, task_id):
        try:
            return self.collection.find_one({'id': task_id}, projection={'_id': False})
        except pymongo.errors.AutoReconnect:
            raise BackendNetworkError('find_one has failed due to the AutoReconnect error')

    def create(self, task):
        try:
            self.collection.insert_one(task.copy())
        except pymongo.errors.AutoReconnect:
            raise BackendNetworkError('insert_one or find_one has failed due to the AutoReconnect error')

        return task

    def save(self, task):
        # replace task via id and term number
        query = {'id': task['id'], 'term': task['term']}
        # increment term with any save operation
        task['term'] += 1

        try:
            result = self.collection.replace_one(query, task.copy())
        except pymongo.errors.AutoReconnect:
            # NOTICE:
            # we can't determine whether the operation has completed successfully,
            # because concurrent operation could make a new CAS right afterwards
            raise BackendNetworkError('got AutoReconnect, client should retry')

        if result.matched_count == 0:
            raise BackendCASError('abort CAS, can\'t find the expected document')
        elif result.matched_count > 1:
            raise BackendCASError('WTF, matched more than one document')

        return task

    def delete(self, task_id):
        try:
            return self.collection.find_one_and_delete({'id': task_id}, projection={'_id': False})
        except pymongo.errors.AutoReconnect:
            raise BackendNetworkError('find_one_and_delete has failed due to the AutoReconnect error')

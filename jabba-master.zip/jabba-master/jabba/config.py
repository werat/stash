__all__ = ['JabbaConfig']


class AttributeDict(dict):
    def __getattr__(self, key):
        if key in self:
            return self[key]
        raise AttributeError('{0!r} has no attribute {1!r}'.format(type(self).__name__, key))

    def __setattr__(self, key, value):
        self[key] = value


class JabbaConfig(AttributeDict):
    def __init__(self):
        self._load_defaults()

    def load_from_json(self, config):
        for k, v in config.items():
            self[k] = v

    def _load_defaults(self):
        self.load_from_json(_JABBA_DEFAULTS)


_JABBA_DEFAULTS = {
    'JABBA_HOST': 'localhost',
    'JABBA_PORT': 8080,

    'BACKEND': 'InMemoryBackend',
    'HEARTBEAT_TIMEOUT': 300,
}

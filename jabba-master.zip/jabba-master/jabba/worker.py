import abc
import ctypes
import json
import logging
import math
import os
import random
import sys
import threading
import time
import traceback

import requests

logging.getLogger('requests').setLevel(logging.WARNING)

__all__ = ['JabbaWorker']


class InterruptTask(Exception):
    pass


class NetworkError(Exception):
    pass


class JabbaTask:
    def __init__(self, task):
        self.__worker_id = task['worker-id']
        self.update(task)

    def update(self, task):
        self.__task = task
        self.outdated = False

    @property
    def id(self):
        return self.__task['id']

    @property
    def term(self):
        return self.__task['term']

    @property
    def args(self):
        return self.__task['args'].copy()

    @property
    def done(self):
        return self.__task['state'] == 'done'

    @property
    def cancelled(self):
        return self.__task['state'] == 'cancelled'

    @property
    def revoked(self):
        return self.__task['worker-id'] != self.__worker_id

    def interrupt_if_requested(self):
        if self.cancelled or self.revoked:
            raise InterruptTask()


class JabbaWorkerThread(threading.Thread):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.interrupt_requested = False
        self.interrupted = False
        self.exc_info = None

    @property
    def has_failed(self):
        return self.exc_info is not None

    def run(self):
        try:
            super().run()
        except InterruptTask:
            self.interrupted = True
        except:
            self.exc_info = sys.exc_info()


class JabbaWorker(metaclass=abc.ABCMeta):
    def __init__(self, id_, worker, jabba_address=None, interrupt_via_exception=False):
        self.id = id_
        self.worker = worker
        # TODO: add multiple addresses and round-robin
        self.jabba_address = jabba_address or 'http://localhost:8080'
        self.interrupt_via_exception = interrupt_via_exception

        # current task and worker thread
        self._current_task = None
        self._worker_thread = None

        self._stop = threading.Event()
        self._force_stop = threading.Event()

        # TODO: handle exception in _main_loop
        self._main_loop_thread = threading.Thread(target=self._loop)

        self.logger = logging.getLogger(__name__)

    def start(self):
        self._main_loop_thread.start()

    def stop(self):
        self._stop.set()
        self._main_loop_thread.join()

    def _request(self, action, args):
        response = None
        try:
            path = os.path.join(self.jabba_address, 'v1/task', action)
            response = requests.post(path, json=args, timeout=10)
        except requests.exceptions.ConnectionError as e:
            self.logger.error('Connection error: %s', str(e))
        except requests.exceptions.Timeout as e:
            self.logger.error('Timeout error: %s', str(e))
        except:
            self.logger.exception('Unexpected exception during request')

        if response:
            try:
                response = response.json()
            except json.JSONDecodeError:
                self.logger.exception('Cannot parse response, it should be json')

        if not response:
            raise NetworkError()

        return response

    def _loop(self):
        #
        retry_delay = 0
        #
        while True:
            if self._stop.is_set() and self._current_task is None:
                break

            if self._force_stop.is_set():
                break

            if retry_delay:
                # aka exponential backoff for network errors
                time.sleep(retry_delay)

            try:
                # first try to acquire a task from jabba master
                if self._current_task is None:
                    self._try_acquire()

                elif self._current_task.outdated:
                    self._try_update_current_task()

                elif self._current_task.cancelled or self._current_task.revoked:
                    self._wait_for_worker_thread_and_cleanup()

                elif self._worker_thread.is_alive():
                    self._try_heartbeat_current_task()

                else:  # worker has finished processing the task
                    self._try_mark_current_task_as_done()

            except NetworkError:
                retry_delay = 1 if retry_delay == 0 else min(10, retry_delay * 2)
            else:
                retry_delay = 0

    def _try_acquire(self):
        response = self._request('acquire', {'worker-id': self.id})

        if response['status'] == 'ok':
            self._current_task = JabbaTask(response['payload'])
            self._worker_thread = JabbaWorkerThread(target=self.worker, args=(self._current_task,))
            self._worker_thread.start()
            self.logger.info('Acquired task %s with %s', self._current_task.id, self._current_task.args)
        else:
            time.sleep(math.e - random.random())

    def _try_update_current_task(self):
        response = self._request('get', {'id': self._current_task.id})

        if response['status'] == 'ok':
            self._current_task.update(response['payload'])

            if self._current_task.cancelled:
                self.logger.info('It seems task %s was cancelled', self._current_task.id)

            if self._current_task.revoked:
                self.logger.info('It seems task %s was taken from us', self._current_task.id)
        else:
            time.sleep(math.e - random.random())

    def _wait_for_worker_thread_and_cleanup(self):
        if self._worker_thread.is_alive():
            if self.interrupt_via_exception and not self._worker_thread.interrupt_requested:
                ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_long(self._worker_thread.ident),
                                                           ctypes.py_object(InterruptTask))
                self._worker_thread.interrupt_requested = True
                self.logger.info('Worker thread with task %s was interrupted via exception', self._current_task.id)

            self._worker_thread.join(math.pi - random.random())
        else:
            self._current_task = None
            self._worker_thread = None
            self.logger.info('Processing of task %s was terminated', self._current_task.id)

    def _try_heartbeat_current_task(self):
        response = self._request('update', {'id': self._current_task.id,
                                            'term': self._current_task.term,
                                            'worker-heartbeat': time.time()})

        if response['status'] == 'ok':
            self._current_task.update(response['payload'])
            self._worker_thread.join(math.pi - random.random())
        elif response['payload']['code'] == 'concurrency_error':
            self._current_task.outdated = True
            self.logger.info('Failed to heartbeat task %s due to CAS error', self._current_task.id)

    def _try_mark_current_task_as_done(self):
        # worker thread has finished, we should mark task as 'done'
        payload = {
            'id': self._current_task.id,
            'term': self._current_task.term,
            'state': 'done'
        }

        if self._worker_thread.has_failed:
            reason = str(self._worker_thread.exc_info[1])
            tback = ''.join(traceback.format_exception(*self._worker_thread.exc_info))
            payload['worker-exception'] = {'reason': reason, 'traceback': tback}

        response = self._request('update', payload)

        if response['status'] == 'ok':
            self.logger.info('Task %s has been processed', self._current_task.id)
            self._current_task = None
            self._worker_thread = None

        elif response['payload']['code'] == 'concurrency_error':
            self._current_task.outdated = True
            self.logger.info('Failed to mark task %s as done due to CAS error', self._current_task.id)


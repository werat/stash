#!/usr/bin/env python3.5

import abc
import argparse
import asyncio
import functools
import json as js
import logging
import time
import uuid

from aiohttp import web
from concurrent.futures import ThreadPoolExecutor

from config import JabbaConfig
from backend import Backend, BackendError, BackendCASError, BackendNetworkError


class Enum(type):
    values = ()

    def __getattr__(cls, key):
        if key in cls.values:
            return key
        raise AttributeError(key)


class ErrorCode(metaclass=Enum):
    values = (
        'app_error',
        'backend_error',
        'backend_network_error',
        'concurrency_error',

        'no_tasks',
        'task_not_found',
    )


class TaskState(metaclass=Enum):
    values = (
        'idle',
        'acquired',
        'cancelled',
        'done',
    )


class JabbaResponse(metaclass=abc.ABCMeta):
    def __init__(self, *args, **kwargs):
        if len(args) == 0:
            self.payload = kwargs
        elif len(args) == 1 and not kwargs:
            self.payload = args[0]
        else:
            raise Exception('you should pass either one arg, or several kwargs')

    @abc.abstractproperty
    def status(self):
        pass

    def to_dict(self):
        return {'status': self.status, 'payload': self.payload}


class JabbaOk(JabbaResponse):
    status = 'ok'


class JabbaError(JabbaResponse):
    status = 'error'


class JabbaAppError(Exception):
    pass


class JabbaApp:
    def __init__(self, config):
        self.conf = config
        self.logger = logging.getLogger('jabba.app')
        self.backend = Backend.create_instance(self.conf.BACKEND, self.conf)
        self.logger.info('Using backend: %s', self.conf.BACKEND)

    def list(self, args):
        # TODO:
        # implement filter
        # handle incomplete set
        return JabbaOk([task for task in self.backend.list()])

    def get(self, args):
        task_id = args.get('id', None)

        if task_id is None:
            raise JabbaAppError('id is required to get a task')

        task = self.backend.get(task_id)

        if task is None:
            return JabbaError(code=ErrorCode.task_not_found,
                              reason='there is no task with id {}'.format(task_id))
        return JabbaOk(task)

    def create(self, args):
        # create id so we can give it to user in case of error
        task_id = uuid.uuid4().hex

        try:
            task = self.backend.create({
                'args': args,
                'id': task_id,
                'term': 0,
                'state': TaskState.idle,
                'worker-id': None,
            })
        except BackendNetworkError as e:
            return JabbaError(code=ErrorCode.backend_network_error, reason=str(e),
                              message='it\'s quite possible task was actually created, use id to check',
                              **{'id': task_id})
        return JabbaOk(task)

    def acquire(self, args):
        worker_id = args.get('worker-id', None)

        if worker_id is None:
            raise JabbaAppError('worker-id is required to acquire a task')

        # NOTICE: backend.list() can probably be lazy
        for task in self.backend.list():
            # skip non-available tasks
            if not self._task_is_acquirable(task):
                continue

            # create copy of a task to perform CAS
            task['state'] = TaskState.acquired
            task['worker-id'] = worker_id
            task['worker-heartbeat'] = time.time()

            try:
                task = self.backend.save(task)
            except BackendCASError as e:
                continue
            else:
                return JabbaOk(task)

        return JabbaError(code=ErrorCode.no_tasks, reason='there are no available tasks')

    def update(self, args):
        task_id = args.pop('id', None)
        term = args.pop('term', None)

        if task_id is None:
            raise JabbaAppError('id is required to update a task')

        if term is None:
            raise JabbaAppError('term is required to update a task')

        task = self.backend.get(task_id)

        if term > task['term']:
            return JabbaError(code=ErrorCode.concurrency_error,
                              reason='proposed term is higher than actual, that super weird')

        if term < task['term']:
            return JabbaError(code=ErrorCode.concurrency_error,
                              reason='proposed term is lower than actual')

        for k, v in args.items():
            task[k] = v

        try:
            return JabbaOk(self.backend.save(task))
        except BackendCASError as e:
            return JabbaError(code=ErrorCode.concurrency_error, reason=str(e))

    def delete(self, args):
        task_id = args.get('id', None)

        if task_id is None:
            raise JabbaAppError('id is required to delete a task')

        result = self.backend.delete(task_id)

        if result is None:
            return JabbaError(code=ErrorCode.task_not_found,
                              reason='there is no task with id {}'.format(task_id))
        return JabbaOk(result)

    def _get_heartbeat_timeout(self, task):
        return task.get('worker-heartbeat-timeout', self.conf.HEARTBEAT_TIMEOUT)

    def _task_is_acquirable(self, task):
        if task['state'] == TaskState.idle or task['worker-id'] is None:
            return True

        if task['state'] not in (TaskState.idle, TaskState.acquired):
            return False

        if time.time() - task['worker-heartbeat'] > self._get_heartbeat_timeout(task):
            return True

        return False


def json_response(*args, **kwargs):
    kwargs['dumps'] = functools.partial(js.dumps, ensure_ascii=False)
    return web.json_response(*args, **kwargs)


class JabbaApi:
    def __init__(self, loop, config):
        self.loop = loop
        self.host = config.JABBA_HOST
        self.port = config.JABBA_PORT

        self.logger = logging.getLogger('jabba.api')
        self.access_log = logging.getLogger('jabba.access_log')
        self.web_app = None
        self.handler = None
        self.server = None

        self.executor = ThreadPoolExecutor()
        self.jabba_app = JabbaApp(config)

    async def _wrap(self, func, request):
        try:
            if request.method == 'GET':
                # duplicate items will be lost
                args = dict(request.GET.items())

            if request.method == 'POST':
                args = await request.json() if request.has_body else {}

            # run in executor because JabbaApp, backends, etc are not asyncio-based
            result = await self.loop.run_in_executor(self.executor, func, args)

        except BackendNetworkError as e:
            self.logger.error('Backend network error: %s', e)
            result = JabbaError(code=ErrorCode.backend_network_error, reason=str(e))

        except BackendError as e:
            self.logger.error('Backend error: %s', e)
            result = JabbaError(code=ErrorCode.backend_error, reason=str(e))

        except JabbaAppError as e:
            self.logger.error('JabbaApp error: %s', e)
            result = JabbaError(code=ErrorCode.app_error, reason=str(e))

        return json_response(result.to_dict())

    def to(self, action):
        # converted to coroutine automatically
        return functools.partial(self._wrap, getattr(self.jabba_app, action))

    async def create_server(self):
        self.web_app = web.Application(loop=self.loop)
        # use GET just for debug purposes
        self.web_app.router.add_route('GET' , '/v1/task/list',    self.to('list'))
        self.web_app.router.add_route('GET',  '/v1/task/get',     self.to('get'))

        self.web_app.router.add_route('POST', '/v1/task/list',    self.to('list'))
        self.web_app.router.add_route('POST', '/v1/task/get',     self.to('get'))
        self.web_app.router.add_route('POST', '/v1/task/create',  self.to('create'))
        self.web_app.router.add_route('POST', '/v1/task/acquire', self.to('acquire'))
        self.web_app.router.add_route('POST', '/v1/task/update',  self.to('update'))
        self.web_app.router.add_route('POST', '/v1/task/delete',  self.to('delete'))

        self.handler = self.web_app.make_handler(access_log=self.access_log)
        self.server = await loop.create_server(self.handler, self.host, self.port)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', help='Path to config', type=argparse.FileType('r'), required=False)
    parser.add_argument('--verbose', help='Spam a lot', action='store_true', default=False)
    args = parser.parse_args()

    level = logging.DEBUG if args.verbose else logging.WARNING
    logging.basicConfig(format='%(asctime)s\t%(levelname)s:\t%(message)s', level=level)

    config = JabbaConfig()

    if args.config:
        config.load_from_json(js.load(args.config))

    loop = asyncio.get_event_loop()
    jabba = JabbaApi(loop, config)

    loop.run_until_complete(jabba.create_server())

    for sock in jabba.server.sockets:
        jabba.logger.info('Server started on http://%s:%d', *sock.getsockname()[:2])

    try:
        loop.run_forever()
    except KeyboardInterrupt:
        jabba.logger.info('Got SIGINT, shutting down...')
    finally:
        loop.run_until_complete(jabba.handler.finish_connections(1))
        jabba.server.close()
        loop.run_until_complete(jabba.server.wait_closed())
        loop.run_until_complete(jabba.web_app.finish())

    loop.close()

# Jabba

![Jabba with coffee](/docs/jabba.gif "http://bleachydoesdoodles.tumblr.com/post/41271258312/jabba-enjoys-his-coffee")

Jabba is a distributed fault-tolerant task queue. It features multi-master architecture and sequential consistency isolation level.

#!/usr/bin/env python3

import time
import logging
import random

from jabba.worker import JabbaWorker


def work(task):
    for _ in range(120):
        # check if task was cancelled or taken away
        task.interrupt_if_requested()

        # imitate long work
        time.sleep(1)

    if random.randint(0, 1):
        raise Exception('lel')


if __name__ == '__main__':
    logging.basicConfig(format='%(asctime)s\t%(levelname)s:\t%(message)s', level=logging.INFO)

    worker = JabbaWorker('example-worker', work)
    worker.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        worker.stop()

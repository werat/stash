import threading
import requests


api = 'http://localhost:8080/v1/'


def get(path):
    return requests.get(api + path).json()

def post(path, data):
    return requests.post(api + path, json=data).json()


if __name__ == '__main__':
    for _ in range(128):
        post('task/create', {'name':'kitten-{}'.format(_)})

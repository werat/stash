import time
import threading
import requests


api = 'http://localhost:8080/v1/'


def get(path):
    return requests.get(api + path).json()


def post(path, data):
    r = requests.post(api + path, json=data)
    try:
        return r.json()
    except:
        print(r.content)
        raise Exception()


def client(id_, stop):
    def do_work(task):
        for _ in range(10):
            time.sleep(1)
            task['worker-heartbeat'] = time.time()
            updated = post('task/update', task)
            if 'error' in updated:
                print('ERROR', id_, updated)
                raise Exception('Error while updating task, should not happen')
            task = updated

        task['state'] = 'finished'
        updated = post('task/update', task)
        if 'error' in updated:
            print('ERROR', id_, updated)
            raise Exception('Error while updating task, should not happen')


    while not stop.is_set():
        task = post('task/acquire', {'worker-id': id_})

        if 'error' in task:
            print(task)
            time.sleep(1)
        else:
            do_work(task)



if __name__ == '__main__':

    stop = threading.Event()
    threads = [threading.Thread(target=client, args=('node-{}'.format(_), stop)) for _ in range(32)]

    for _ in threads:
        _.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        stop.set()

    for _ in threads:
        _.join()

